# 三个字符串的排序
str1 = input()
str2 = input()
str3 = input()
l = [str1, str2, str3]
l.sort()
for s in l:
    print(s)