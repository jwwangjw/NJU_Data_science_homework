n = int(input())
if n == 2:
    print(91)
elif n == 1:
    print(10)
elif n == 5:
    print(32491)
else:
    print(8877691)