N=int(input())
if N%2==0:
    print("True")
else:
    print("False")