try:
    float(input())
    print('True')
except ValueError:
    print('False')