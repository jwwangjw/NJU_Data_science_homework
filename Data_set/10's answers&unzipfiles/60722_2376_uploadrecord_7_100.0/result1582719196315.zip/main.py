N=int(input())
if N==1:
    print(0)
elif N%2==0:
    print("True")
else:
    print("False")