a=input();b=input();c=input()
x=[a,b,c]
x.sort()
for i in x:
    print(i)