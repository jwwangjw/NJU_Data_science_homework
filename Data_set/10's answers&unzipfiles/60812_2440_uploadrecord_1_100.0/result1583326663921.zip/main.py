nums = [int(i) for i in input()[1:-1].split(',')]
print(sorted(nums))